
document.getElementsByTagName('h2').onclick = function()
{
    alert('you clicked me');
}
;
